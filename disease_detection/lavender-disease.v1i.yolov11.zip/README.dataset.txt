# lavender-disease > 2025-01-09 7:11pm
https://universe.roboflow.com/graduationproject-ncw2h/lavender-disease

Provided by a Roboflow user
License: CC BY 4.0

